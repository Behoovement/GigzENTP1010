const userReviews = {
    "Alex Johnson": [{ reviewer: "Emily Clark", rating: 5, comment: "Electrifying performance!" }],
    "Maria Lopez": [{ reviewer: "Sophia Martinez", rating: 5, comment: "Captivating poet!" }]
};
const eventReviews = {
    "Open Mic Poetry Slam": [{ reviewer: "Emma Roberts", rating: 5, comment: "Profound poetry night." }],
    "Indie Night Jam": [{ reviewer: "Charlotte Green", rating: 5, comment: "Phenomenal indie bands." }]
};