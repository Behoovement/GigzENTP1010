document.getElementById('signupForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Signed up successfully!');
});

document.getElementById('loginForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Logged in successfully!');
});